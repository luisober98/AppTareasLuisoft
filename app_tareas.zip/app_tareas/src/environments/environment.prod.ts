export const environment = {
  production: true,
  firebaseConfig: {
    apiKey: "AIzaSyAfho5sRWScFCv5E1dy-Oq89TnbhZ7r4J8",
    authDomain: "apptareas-luisoft.firebaseapp.com",
    projectId: "apptareas-luisoft",
    storageBucket: "apptareas-luisoft.appspot.com",
    messagingSenderId: "868859512558",
    appId: "1:868859512558:web:aff2c494579ccdb56155ff",
    measurementId: "G-GTGTVVLVD1"
  }
};
